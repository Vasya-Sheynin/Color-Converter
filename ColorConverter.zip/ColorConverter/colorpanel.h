
#ifndef COLORPANEL_H
#define COLORPANEL_H

#include <QtWidgets>

class ColorPanel : public QWidget
{

    Q_OBJECT

public:
    enum ColorType {RGB, CMYK, HSV, HLS, XYZ, LAB};

    explicit ColorPanel(QWidget *parent = nullptr);
    void createPanel(QGridLayout* grid, ColorType type);
    void setColorComponents(double val1, double val2, double val3);

signals:
    void colorSignal(QColor color);

private:
    double component1;
    double component2;
    double component3;
    double component4;

    ColorType type;

    QSlider *slider1 = new QSlider(Qt::Horizontal);
    QSlider *slider2 = new QSlider(Qt::Horizontal);
    QSlider *slider3 = new QSlider(Qt::Horizontal);
    QSlider *slider4 = new QSlider(Qt::Horizontal);

    QLabel *colorLabel = new QLabel();
    QLabel *lbl1 = new QLabel();
    QLabel *lbl2 = new QLabel();
    QLabel *lbl3 = new QLabel();
    QLabel *lbl4 = new QLabel();

    QLineEdit *line1 = new QLineEdit();
    QLineEdit *line2 = new QLineEdit();
    QLineEdit *line3 = new QLineEdit();
    QLineEdit *line4 = new QLineEdit();

    void sendColor();
};

#endif // COLORPANEL_H
