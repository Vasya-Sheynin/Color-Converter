
#include "colorpanel.h"

ColorPanel::ColorPanel(QWidget *parent)
    : QWidget{parent}
{
    connect(slider1, &QSlider::valueChanged, this, [=](int value) {
        line1->setText(QString::number(value));
        sendColor();
    });

    connect(slider2, &QSlider::valueChanged, this, [=](int value) {
        line2->setText(QString::number(value));
        sendColor();
    });

    connect(slider3, &QSlider::valueChanged, this, [=](int value) {
        line3->setText(QString::number(value));
        sendColor();
    });

    connect(slider4, &QSlider::valueChanged, this, [=](int value) {
        line4->setText(QString::number(value));
        sendColor();
    });

    connect(line1, &QLineEdit::textChanged, this, [=]() {
        slider1->setSliderPosition(line1->text().toInt());
        slider1->setValue(line1->text().toInt());
    });

    connect(line2, &QLineEdit::textChanged, this, [=]() {
        slider2->setSliderPosition(line2->text().toInt());
        slider2->setValue(line2->text().toInt());
    });

    connect(line3, &QLineEdit::textChanged, this, [=]() {
        slider3->setSliderPosition(line3->text().toInt());
        slider3->setValue(line3->text().toInt());
    });

    connect(line4, &QLineEdit::textChanged, this, [=]() {
        slider4->setSliderPosition(line4->text().toInt());
        slider4->setValue(line4->text().toInt());
    });
}

void ColorPanel::createPanel(QGridLayout *grid, ColorType type)
{
    this->type = type;

    QString font = "font: 12pt Segoe UI;";

    colorLabel->setStyleSheet(font);

    lbl1->setStyleSheet(font);
    lbl2->setStyleSheet(font);
    lbl3->setStyleSheet(font);
    lbl4->setStyleSheet(font);

    line1->setStyleSheet(font);
    line2->setStyleSheet(font);
    line3->setStyleSheet(font);
    line4->setStyleSheet(font);

    grid->addWidget(colorLabel, 0, 0, 1, 3, Qt::AlignCenter);
    grid->addWidget(lbl1, 1, 0, Qt::AlignCenter);
    grid->addWidget(lbl2, 2, 0, Qt::AlignCenter);
    grid->addWidget(lbl3, 3, 0, Qt::AlignCenter);
    grid->addWidget(line1, 1, 1, Qt::AlignCenter);
    grid->addWidget(line2, 2, 1, Qt::AlignCenter);
    grid->addWidget(line3, 3, 1, Qt::AlignCenter);
    grid->addWidget(slider1, 1, 2);
    grid->addWidget(slider2, 2, 2);
    grid->addWidget(slider3, 3, 2);

    line1->setMaximumSize(92, 25);
    line2->setMaximumSize(92, 25);
    line3->setMaximumSize(92, 25);
    line4->setMaximumSize(92, 25);

    grid->setColumnStretch(2, 1);
    grid->setHorizontalSpacing(25);

    switch (type)
    {
    case ColorType::CMYK:
    {
        colorLabel->setText("<center> Color model: CMYK </center>");

        lbl1->setText("<center> C </center>");
        lbl2->setText("<center> M </center>");
        lbl3->setText("<center> Y </center>");
        lbl4->setText("<center> K </center>");

        QRegExpValidator *validator = new QRegExpValidator(
            QRegExp("^(0|[1-9]\\d?|100)$"));

        line1->setText("0");
        line2->setText("0");
        line3->setText("0");
        line4->setText("0");

        line1->setValidator(validator);
        line2->setValidator(validator);
        line3->setValidator(validator);
        line4->setValidator(validator);

        slider1->setRange(0, 100);
        slider2->setRange(0, 100);
        slider3->setRange(0, 100);
        slider4->setRange(0, 100);

        slider1->setValue(0);
        slider2->setValue(0);
        slider3->setValue(0);
        slider4->setValue(0);

        break;
    }
    case ColorType::HLS:
    {

        break;
    }
    case ColorType::HSV:
    {

        break;
    }
    case ColorType::LAB:
    {
        colorLabel->setText("<center> Color model: LAB </center>");

        lbl1->setText("<center> L </center>");
        lbl2->setText("<center> A </center>");
        lbl3->setText("<center> B </center>");

        QRegExpValidator *validator1 = new QRegExpValidator(
            QRegExp("^(0|[1-9]\\d?|100)$"));

        QRegExpValidator *validator2 = new QRegExpValidator(
            QRegExp("^-?(0|[1-9]\\d?|100)$"));

        line1->setText("100");
        line2->setText("0");
        line3->setText("0");

        line1->setValidator(validator1);
        line2->setValidator(validator2);
        line3->setValidator(validator2);

        slider1->setRange(0, 100);
        slider2->setRange(-100, 100);
        slider3->setRange(-100, 100);

        slider1->setValue(100);
        slider2->setValue(0);
        slider3->setValue(0);

        break;
    }
    case ColorType::RGB:
    {
        colorLabel->setText("<center> Color model: RGB </center>");

        lbl1->setText("<center> R </center>");
        lbl2->setText("<center> G </center>");
        lbl3->setText("<center> B </center>");

        QRegExpValidator *validator = new QRegExpValidator(
            QRegExp("^(0|[1-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-5])$"));

        line1->setText("255");
        line2->setText("255");
        line3->setText("255");

        line1->setValidator(validator);
        line2->setValidator(validator);
        line3->setValidator(validator);

        slider1->setRange(0, 255);
        slider2->setRange(0, 255);
        slider3->setRange(0, 255);

        slider1->setValue(255);
        slider2->setValue(255);
        slider3->setValue(255);

        break;
    }
    case ColorType::XYZ:
    {

        break;
    }
    }
}

void ColorPanel::setColorComponents(double val1, double val2, double val3)
{
    switch (type)
    {
    case ColorType::CMYK:
    {

        break;
    }
    case ColorType::HLS:
    {

        break;
    }
    case ColorType::HSV:
    {

        break;
    }
    case ColorType::LAB:
    {

        break;
    }
    case ColorType::RGB:
    {
        line1->setText(QString::number(val1));
        line2->setText(QString::number(val2));
        line3->setText(QString::number(val3));
        break;
    }
    case ColorType::XYZ:
    {

        break;
    }
    }
}

void ColorPanel::sendColor()
{
    int r, g, b;
    switch (type)
    {
    case ColorType::CMYK:
    {

        break;
    }
    case ColorType::HLS:
    {

        break;
    }
    case ColorType::HSV:
    {

        break;
    }
    case ColorType::LAB:
    {

        break;
    }
    case ColorType::RGB:
    {
        r = slider1->value();
        g = slider2->value();
        b = slider3->value();
        break;
    }
    case ColorType::XYZ:
    {

        break;
    }
    }

    emit colorSignal(QColor(r, g, b));
}
